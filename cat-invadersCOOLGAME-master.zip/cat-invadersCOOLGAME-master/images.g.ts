// Auto-generated code. Do not edit.
namespace myImages {

    helpers._registerFactory("image", function(name: string) {
        switch(helpers.stringTrim(name)) {
            case "image1":
            case "ninja":return img`
. . . . f f f f f . . . 
. . . f f f f f f f . . 
f . f f f f f f f f f . 
. f f b f f f f f b f . 
f . f d 1 1 b 1 1 d f . 
. . f f 1 f d f 1 f f . 
. . . f f f f f f f . . 
. . . . f f f f f . . . 
. . . f f f f f f f . . 
. . f f f f f f f f f . 
. . f f f f f f f f f . 
. f . f f f f f f f . f 
. f . f f f f f f f . f 
. . . . f f f f f . . . 
. . . . f f . f f . . . 
. . . f f f . f f f . . 
`;
            case "P!SN:(/KL=)hR}9=bfH@":
            case "ninjaStar":return img`
. . . f f . . . . . . . . . . . 
. . . f f f f . . . . . . . . . 
. . . . f 8 f f . . . . . f f . 
. . . . f f 8 f . . . f f f f . 
. . . . . f f f . . f f 8 f . . 
. . . . . . f f f f f 8 f f . . 
. . . . . . f 8 8 f f f f . . . 
. . . f f f f 8 8 f . . . . . . 
. . f f 8 f f f f f . . . . . . 
. . f 8 f f . . f f f . . . . . 
. f f f f . . . f 8 f f . . . . 
. f f . . . . . f f 8 f . . . . 
. . . . . . . . . f f f f . . . 
. . . . . . . . . . . f f . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`;
        }
        return null;
    })

    helpers._registerFactory("animation", function(name: string) {
        switch(helpers.stringTrim(name)) {

        }
        return null;
    })

    helpers._registerFactory("song", function(name: string) {
        switch(helpers.stringTrim(name)) {

        }
        return null;
    })

}
// Auto-generated code. Do not edit.
